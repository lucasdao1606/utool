"""Tool Quan ly & Phan bo Danh muc (VAM-style)."""
