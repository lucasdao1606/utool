"""Logic tinh toan thuan Python cho Investment (khong phu thuoc Streamlit)."""
import pandas as pd

def compute_vam_portfolio_summary(data: list = None) -> dict:
    """Tinh toan tong gia tri danh muc va tin hieu rebalance."""
    if not data:
        return {
            "total_value": 1250000000,
            "cash_ratio": 0.10,
            "risk_score": 0.62,
            "rebalance_action": "Toi uu hoa ty trong"
        }
    df = pd.DataFrame(data)
    total_val = df["market_value"].sum() if "market_value" in df.columns else 0
    return {
        "total_value": total_val,
        "cash_ratio": 0.15,
        "risk_score": 0.55,
        "rebalance_action": "Giu nguyen ty trong"
    }
