import streamlit as st
import pandas as pd
from common.helpers import format_currency_vnd, export_df_to_excel_csv
from tools.tool_investment.engine import compute_vam_portfolio_summary

def render_investment_tool():
    st.header("📈 Phân bổ Danh mục & Định giá (VAM)")
    st.caption("Quản trị danh mục, tính toán Composite Valuation Index và tín hiệu rebalance.")
    
    tab1, tab2, tab3 = st.tabs(["📊 Tổng quan & Tỷ trọng", "⚙️ Cập nhật Dữ liệu", "📋 Export & Logs"])
    
    with tab1:
        summary = compute_vam_portfolio_summary()
        col1, col2, col3 = st.columns(3)
        col1.metric("Tổng tài sản ước tính", format_currency_vnd(summary["total_value"]), "+1.8%")
        col2.metric("Chỉ số định giá", f"{summary['risk_score']:.2f}", "-0.04")
        col3.metric("Tín hiệu Rebalance", summary["rebalance_action"])
        
        st.divider()
        st.subheader("Phân bổ tài sản hiện tại")
        sample_df = pd.DataFrame({
            "Mã / Loại tài sản": ["Cổ phiếu (Index ETF)", "Trái phiếu / Tiết kiệm", "Crypto (BTC/BNB)", "Tiền mặt"],
            "Tỷ trọng mục tiêu (%)": [45, 30, 15, 10],
            "Tỷ trọng thực tế (%)": [48, 28, 14, 10],
            "Độ lệch (%)": ["+3%", "-2%", "-1%", "0%"]
        })
        st.dataframe(sample_df, use_container_width=True)

    with tab2:
        st.subheader("Cập nhật tham số & giá thị trường")
        with st.form("update_market_data"):
            st.text_input("Tải lại API hoặc nhập mã danh mục:")
            submitted = st.form_submit_button("Đồng bộ dữ liệu")
            if submitted:
                st.success("Đã đồng bộ thông số thị trường thành công!")

    with tab3:
        st.subheader("Xuất báo cáo dữ liệu")
        csv_bytes = export_df_to_excel_csv(sample_df)
        st.download_button(
            label="📥 Tải CSV báo cáo (UTF-8 BOM)",
            data=csv_bytes,
            file_name="portfolio_allocation.csv",
            mime="text/csv"
        )
