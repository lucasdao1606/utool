"""Shared UI components & utilities."""
